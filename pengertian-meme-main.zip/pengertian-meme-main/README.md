# pengertian-meme
Pangertian apa itu sebenarnya meme dangan website sederhana
